﻿using HarSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using winFormHar.Helpers;

namespace winFormHar
{
    public partial class formHarProcessor : Form
    {
        private readonly Dictionary<string, string> fileNameLookupDictionary = new Dictionary<string, string>();
        private readonly Dictionary<string, (int rows, int? sizes, double? times)> statisticsDict = new Dictionary<string, (int rows, int? sizes, double? times)>();

        public formHarProcessor()
        {
            InitializeComponent();
        }

        private void InitializeDisplay()
        {
            statisticsDict.Clear();
            dataGridViewHAR.DataSource = null;
            labelTotalTime.Text = String.Empty;
            labelStatistics.Text = "Statistics:";

        }

        private void BtnSelectHARFolder_Click(object sender, EventArgs e)
        {
            InitializeDisplay();
            listBoxHARFiles.Items.Clear();
            listBoxHARFiles.ShowFolderDialogAndAddHARFilesToListBox(fileNameLookupDictionary);
            listBoxHARFiles.UpdateListBoxIfNoHARFiles();
        }

        private void ListBoxHARFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            InitializeDisplay();
            if (listBoxHARFiles.NoItemsInListbox()) { return; }
            Har harData = HarConvert.DeserializeFromFile(fileNameLookupDictionary[listBoxHARFiles.SelectedItem.ToString()]);            

            using (DataTable harTable = new DataTable())
            {
                ManageHarDataTable(harData, harTable);
            }

            dataGridViewHAR.UpdateDataGridColumnDefinitions();
        }

        private void ManageHarDataTable(Har harData, DataTable harTable)
        {
            harTable.DefineHarTableColumns();
            double? totalTime = harTable.ProcessHarDataTable(harData, statisticsDict);

            dataGridViewHAR.DataSource = harTable;
            dataGridViewHAR.ColourHarDataGridView();

            labelTotalTime.Text = "Total time (All rows): " + totalTime.ToConvertedTime();
            dataGridViewHAR.CurrentCell.Selected = false;
        }

        private void dataGridViewHAR_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            labelStatistics.StatisticsDisplayForNoRowsSelected(e.RowIndex);
            labelStatistics.StatisticsDisplayForASelectedRow(e.RowIndex, dataGridViewHAR, statisticsDict);
        }

        private void dataGridViewHAR_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData & Keys.KeyCode)
            {
                case Keys.Up:
                case Keys.Down:
                    int index = e.KeyCode == Keys.Up ? 1 : e.KeyCode == Keys.Down ? 1 : 0;
                    int rowIndex = dataGridViewHAR.CurrentCell.RowIndex + index;
                    labelStatistics.StatisticsDisplayForNoRowsSelected(rowIndex);
                    labelStatistics.StatisticsDisplayForASelectedRow(rowIndex, dataGridViewHAR, statisticsDict);
                    break;
            }
        }
    }
}
