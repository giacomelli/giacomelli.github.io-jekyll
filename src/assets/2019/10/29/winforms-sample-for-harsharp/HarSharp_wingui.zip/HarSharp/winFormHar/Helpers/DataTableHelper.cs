﻿using HarSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winFormHar.Helpers
{
    public static class DataTableHelper
    {
        public static string Har_Id = nameof(Har_Id);
        public static string Har_DateTime = nameof(Har_DateTime);
        public static string Har_Name = nameof(Har_Name);
        public static string Har_Status = nameof(Har_Status);
        public static string Har_StatusText = nameof(Har_StatusText);
        public static string Har_Size = nameof(Har_Size);
        public static string Har_Time = nameof(Har_Time);

        public static void DefineHarTableColumns(this DataTable harTable)
        {
            harTable.Columns.Add(Har_Id, typeof(int));
            harTable.Columns.Add(Har_DateTime, typeof(string));
            harTable.Columns.Add(Har_Name, typeof(string));
            harTable.Columns.Add(Har_Status, typeof(string));
            harTable.Columns.Add(Har_StatusText, typeof(string));
            harTable.Columns.Add(Har_Size, typeof(string));
            harTable.Columns.Add(Har_Time, typeof(string));
        }

        public static double? ProcessHarDataTable(this DataTable harTable, Har harData, Dictionary<string, (int rows, int? sizes, double? times)> statisticsDict)
        {
            double? totalTime = 0.0;
            int i = 1;
            foreach (var entry in harData.Log.Entries)
            {
                DataRow row = harTable.NewRow();
                string entryName = SetDataGridRowValues(ref i, entry, row);

                // Interesting: UpdateStatisticsForNewEntry should be after UpdateStatisticsWhereEntryInDictionary, 
                // if other way round the entry gets added twice as the entry gets created and then updated as it exists
                UpdateStatisticsWhereEntryInDictionary(statisticsDict, entry, entryName);
                UpdateStatisticsForNewEntry(statisticsDict, entry, entryName);

                totalTime += entry.Time ?? 0;
                harTable.Rows.Add(row);
            }
            return totalTime;
        }

        private static string SetDataGridRowValues(ref int i, Entry entry, DataRow row)
        {
            string url = entry.Request.Url.ToString();
            int urlStartIndex = url.LastIndexOf("/") + 1;
            string entryName = url.Substring(urlStartIndex, url.Length - urlStartIndex);
            row[DataTableHelper.Har_Id] = i++;
            row[DataTableHelper.Har_DateTime] = entry.StartedDateTime.ToString();
            row[DataTableHelper.Har_Name] = entryName;
            row[DataTableHelper.Har_Status] = entry.Response.Status;
            row[DataTableHelper.Har_StatusText] = entry.Response.StatusText;

            row[DataTableHelper.Har_Size] = (entry.Response.HeadersSize + (entry.Response.BodySize ?? 0)).ToConvertedSize();
            row[DataTableHelper.Har_Time] = entry.Time.ToConvertedTime();
            return entryName;
        }

        private static void UpdateStatisticsForNewEntry(Dictionary<string, (int rows, int? sizes, double? times)> statisticsDict, Entry entry, string entryName)
        {
            if (!statisticsDict.ContainsKey(entryName))
            {
                statisticsDict.Add(entryName, (1, entry.Response.HeadersSize + (entry.Response.BodySize ?? 0), entry.Time));
            }
        }

        private static void UpdateStatisticsWhereEntryInDictionary(Dictionary<string, (int rows, int? sizes, double? times)> statisticsDict, Entry entry, string entryName)
        {
            if (statisticsDict.ContainsKey(entryName))
            {
                int numberOfRows = statisticsDict[entryName].rows + 1;
                int? combinedSize = statisticsDict[entryName].sizes + (entry.Response.HeadersSize + (entry.Response.BodySize ?? 0));
                double? combinedTimes = statisticsDict[entryName].times + entry.Time;
                statisticsDict[entryName] = (numberOfRows, combinedSize, combinedTimes);
            }
        }
    }
}
