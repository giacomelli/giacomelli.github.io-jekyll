﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winFormHar.Helpers
{
    public static class DataGridViewColumnHelper
    {
        public static void UpdateDataGridColumnDefinitions(this DataGridView dataGridViewHAR)
        {
            bool nameProcessed = false;
            bool sizeProcessed = false;
            bool timeProcessed = false;
            bool datetimeProcessed = false;
            for (int j = 0; j < dataGridViewHAR.Columns.Count; j++)
            {
                dataGridViewHAR.FixColumnHeaderText(j);
                datetimeProcessed = dataGridViewHAR.ProcessHarDateTimeColumn(datetimeProcessed, j);
                nameProcessed = dataGridViewHAR.ProcessHarNameColumn(nameProcessed, j);
                sizeProcessed = dataGridViewHAR.ProcessHarSizeColumn(sizeProcessed, j);
                timeProcessed = dataGridViewHAR.ProcessHarTimeColumn(timeProcessed, j);
            }
        }

        public static bool ProcessHarTimeColumn(this DataGridView dataGridViewHAR, bool timeProcessed, int colIndex)
        {
            if (!timeProcessed && dataGridViewHAR.Columns[colIndex].HeaderText.ToLower().Equals("time", StringComparison.OrdinalIgnoreCase))
            {
                dataGridViewHAR.Columns[colIndex].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                timeProcessed = true;
            }

            return timeProcessed;
        }

        public static bool ProcessHarSizeColumn(this DataGridView dataGridViewHAR, bool sizeProcessed, int colIndex)
        {
            if (!sizeProcessed && dataGridViewHAR.Columns[colIndex].HeaderText.ToLower().Equals("size", StringComparison.OrdinalIgnoreCase))
            {
                dataGridViewHAR.Columns[colIndex].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                sizeProcessed = true;
            }

            return sizeProcessed;
        }

        public static bool ProcessHarNameColumn(this DataGridView dataGridViewHAR, bool nameProcessed, int colIndex)
        {
            if (!nameProcessed && dataGridViewHAR.Columns[colIndex].HeaderText.ToLower().Equals("name", StringComparison.OrdinalIgnoreCase))
            {
                dataGridViewHAR.Columns[colIndex].MinimumWidth = 350;
                nameProcessed = true;
            }

            return nameProcessed;
        }

        public static bool ProcessHarDateTimeColumn(this DataGridView dataGridViewHAR, bool datetimeProcessed, int colIndex)
        {
            if (!datetimeProcessed && dataGridViewHAR.Columns[colIndex].HeaderText.ToLower().Equals("datetime", StringComparison.OrdinalIgnoreCase))
            {
                dataGridViewHAR.Columns[colIndex].MinimumWidth = 200;
                datetimeProcessed = true;
            }

            return datetimeProcessed;
        }

        public static void FixColumnHeaderText(this DataGridView dataGridViewHAR, int colIndex)
        {
            dataGridViewHAR.Columns[colIndex].HeaderText = dataGridViewHAR.Columns[colIndex].HeaderText.Replace("Har_", "");
        }
    }
}
