﻿namespace winFormHar
{
    partial class formHarProcessor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainerMain = new System.Windows.Forms.SplitContainer();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.panelLeftBottom = new System.Windows.Forms.Panel();
            this.listBoxHARFiles = new System.Windows.Forms.ListBox();
            this.panelInfo = new System.Windows.Forms.Panel();
            this.labelSelectHARFile = new System.Windows.Forms.Label();
            this.labelStep2 = new System.Windows.Forms.Label();
            this.panelLeftTop = new System.Windows.Forms.Panel();
            this.btnSelectHARFolder = new System.Windows.Forms.Button();
            this.labelSelectHARFolder = new System.Windows.Forms.Label();
            this.labelStep1 = new System.Windows.Forms.Label();
            this.dataGridViewHAR = new System.Windows.Forms.DataGridView();
            this.panelToolBar = new System.Windows.Forms.Panel();
            this.labelStatistics = new System.Windows.Forms.Label();
            this.labelTotalTime = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerMain)).BeginInit();
            this.splitContainerMain.Panel1.SuspendLayout();
            this.splitContainerMain.Panel2.SuspendLayout();
            this.splitContainerMain.SuspendLayout();
            this.panelLeft.SuspendLayout();
            this.panelLeftBottom.SuspendLayout();
            this.panelInfo.SuspendLayout();
            this.panelLeftTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHAR)).BeginInit();
            this.panelToolBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainerMain
            // 
            this.splitContainerMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerMain.Location = new System.Drawing.Point(0, 0);
            this.splitContainerMain.Name = "splitContainerMain";
            // 
            // splitContainerMain.Panel1
            // 
            this.splitContainerMain.Panel1.Controls.Add(this.panelLeft);
            // 
            // splitContainerMain.Panel2
            // 
            this.splitContainerMain.Panel2.Controls.Add(this.dataGridViewHAR);
            this.splitContainerMain.Panel2.Controls.Add(this.panelToolBar);
            this.splitContainerMain.Size = new System.Drawing.Size(1784, 561);
            this.splitContainerMain.SplitterDistance = 578;
            this.splitContainerMain.TabIndex = 0;
            // 
            // panelLeft
            // 
            this.panelLeft.Controls.Add(this.panelLeftBottom);
            this.panelLeft.Controls.Add(this.panelLeftTop);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(578, 561);
            this.panelLeft.TabIndex = 0;
            // 
            // panelLeftBottom
            // 
            this.panelLeftBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLeftBottom.Controls.Add(this.listBoxHARFiles);
            this.panelLeftBottom.Controls.Add(this.panelInfo);
            this.panelLeftBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLeftBottom.Location = new System.Drawing.Point(0, 179);
            this.panelLeftBottom.Name = "panelLeftBottom";
            this.panelLeftBottom.Size = new System.Drawing.Size(578, 382);
            this.panelLeftBottom.TabIndex = 2;
            // 
            // listBoxHARFiles
            // 
            this.listBoxHARFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxHARFiles.FormattingEnabled = true;
            this.listBoxHARFiles.HorizontalScrollbar = true;
            this.listBoxHARFiles.Location = new System.Drawing.Point(0, 81);
            this.listBoxHARFiles.Name = "listBoxHARFiles";
            this.listBoxHARFiles.ScrollAlwaysVisible = true;
            this.listBoxHARFiles.Size = new System.Drawing.Size(576, 299);
            this.listBoxHARFiles.TabIndex = 4;
            this.listBoxHARFiles.SelectedIndexChanged += new System.EventHandler(this.ListBoxHARFiles_SelectedIndexChanged);
            // 
            // panelInfo
            // 
            this.panelInfo.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelInfo.Controls.Add(this.labelSelectHARFile);
            this.panelInfo.Controls.Add(this.labelStep2);
            this.panelInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelInfo.ForeColor = System.Drawing.Color.White;
            this.panelInfo.Location = new System.Drawing.Point(0, 0);
            this.panelInfo.Name = "panelInfo";
            this.panelInfo.Size = new System.Drawing.Size(576, 81);
            this.panelInfo.TabIndex = 3;
            // 
            // labelSelectHARFile
            // 
            this.labelSelectHARFile.AutoSize = true;
            this.labelSelectHARFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSelectHARFile.Location = new System.Drawing.Point(28, 45);
            this.labelSelectHARFile.Name = "labelSelectHARFile";
            this.labelSelectHARFile.Size = new System.Drawing.Size(139, 20);
            this.labelSelectHARFile.TabIndex = 3;
            this.labelSelectHARFile.Text = "Select a HAR File:";
            // 
            // labelStep2
            // 
            this.labelStep2.AutoSize = true;
            this.labelStep2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStep2.Location = new System.Drawing.Point(11, 13);
            this.labelStep2.Name = "labelStep2";
            this.labelStep2.Size = new System.Drawing.Size(63, 24);
            this.labelStep2.TabIndex = 2;
            this.labelStep2.Text = "Step 2";
            // 
            // panelLeftTop
            // 
            this.panelLeftTop.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelLeftTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLeftTop.Controls.Add(this.btnSelectHARFolder);
            this.panelLeftTop.Controls.Add(this.labelSelectHARFolder);
            this.panelLeftTop.Controls.Add(this.labelStep1);
            this.panelLeftTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLeftTop.ForeColor = System.Drawing.Color.White;
            this.panelLeftTop.Location = new System.Drawing.Point(0, 0);
            this.panelLeftTop.Name = "panelLeftTop";
            this.panelLeftTop.Size = new System.Drawing.Size(578, 179);
            this.panelLeftTop.TabIndex = 0;
            // 
            // btnSelectHARFolder
            // 
            this.btnSelectHARFolder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectHARFolder.ForeColor = System.Drawing.Color.White;
            this.btnSelectHARFolder.Location = new System.Drawing.Point(60, 97);
            this.btnSelectHARFolder.Name = "btnSelectHARFolder";
            this.btnSelectHARFolder.Size = new System.Drawing.Size(124, 23);
            this.btnSelectHARFolder.TabIndex = 32;
            this.btnSelectHARFolder.Text = "Select Folder";
            this.btnSelectHARFolder.Click += new System.EventHandler(this.BtnSelectHARFolder_Click);
            // 
            // labelSelectHARFolder
            // 
            this.labelSelectHARFolder.AutoSize = true;
            this.labelSelectHARFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSelectHARFolder.Location = new System.Drawing.Point(28, 40);
            this.labelSelectHARFolder.Name = "labelSelectHARFolder";
            this.labelSelectHARFolder.Size = new System.Drawing.Size(178, 20);
            this.labelSelectHARFolder.TabIndex = 1;
            this.labelSelectHARFolder.Text = "Select HAR Files folder:";
            // 
            // labelStep1
            // 
            this.labelStep1.AutoSize = true;
            this.labelStep1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStep1.Location = new System.Drawing.Point(11, 8);
            this.labelStep1.Name = "labelStep1";
            this.labelStep1.Size = new System.Drawing.Size(63, 24);
            this.labelStep1.TabIndex = 0;
            this.labelStep1.Text = "Step 1";
            // 
            // dataGridViewHAR
            // 
            this.dataGridViewHAR.AllowUserToAddRows = false;
            this.dataGridViewHAR.AllowUserToDeleteRows = false;
            this.dataGridViewHAR.AllowUserToResizeRows = false;
            this.dataGridViewHAR.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridViewHAR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHAR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewHAR.Location = new System.Drawing.Point(0, 121);
            this.dataGridViewHAR.MultiSelect = false;
            this.dataGridViewHAR.Name = "dataGridViewHAR";
            this.dataGridViewHAR.ReadOnly = true;
            this.dataGridViewHAR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewHAR.Size = new System.Drawing.Size(1202, 440);
            this.dataGridViewHAR.TabIndex = 38;
            this.dataGridViewHAR.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewHAR_CellClick);
            this.dataGridViewHAR.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridViewHAR_KeyDown);
            // 
            // panelToolBar
            // 
            this.panelToolBar.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelToolBar.Controls.Add(this.labelStatistics);
            this.panelToolBar.Controls.Add(this.labelTotalTime);
            this.panelToolBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelToolBar.ForeColor = System.Drawing.Color.White;
            this.panelToolBar.Location = new System.Drawing.Point(0, 0);
            this.panelToolBar.Name = "panelToolBar";
            this.panelToolBar.Size = new System.Drawing.Size(1202, 121);
            this.panelToolBar.TabIndex = 37;
            // 
            // labelStatistics
            // 
            this.labelStatistics.AutoSize = true;
            this.labelStatistics.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatistics.Location = new System.Drawing.Point(13, 52);
            this.labelStatistics.Name = "labelStatistics";
            this.labelStatistics.Size = new System.Drawing.Size(82, 20);
            this.labelStatistics.TabIndex = 35;
            this.labelStatistics.Text = "Statistics: ";
            // 
            // labelTotalTime
            // 
            this.labelTotalTime.AutoSize = true;
            this.labelTotalTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalTime.Location = new System.Drawing.Point(13, 98);
            this.labelTotalTime.Name = "labelTotalTime";
            this.labelTotalTime.Size = new System.Drawing.Size(13, 20);
            this.labelTotalTime.TabIndex = 34;
            this.labelTotalTime.Text = " ";
            // 
            // formHarProcessor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1784, 561);
            this.Controls.Add(this.splitContainerMain);
            this.MinimumSize = new System.Drawing.Size(1400, 600);
            this.Name = "formHarProcessor";
            this.Text = "Har File Analyzer";
            this.splitContainerMain.Panel1.ResumeLayout(false);
            this.splitContainerMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerMain)).EndInit();
            this.splitContainerMain.ResumeLayout(false);
            this.panelLeft.ResumeLayout(false);
            this.panelLeftBottom.ResumeLayout(false);
            this.panelInfo.ResumeLayout(false);
            this.panelInfo.PerformLayout();
            this.panelLeftTop.ResumeLayout(false);
            this.panelLeftTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHAR)).EndInit();
            this.panelToolBar.ResumeLayout(false);
            this.panelToolBar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainerMain;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Panel panelLeftBottom;
        private System.Windows.Forms.Panel panelLeftTop;
        private System.Windows.Forms.Label labelStep1;
        private System.Windows.Forms.Panel panelInfo;
        private System.Windows.Forms.Label labelSelectHARFile;
        private System.Windows.Forms.Label labelStep2;
        private System.Windows.Forms.Label labelSelectHARFolder;
        private System.Windows.Forms.ListBox listBoxHARFiles;
        protected internal System.Windows.Forms.Button btnSelectHARFolder;
        private System.Windows.Forms.DataGridView dataGridViewHAR;
        private System.Windows.Forms.Panel panelToolBar;
        private System.Windows.Forms.Label labelTotalTime;
        private System.Windows.Forms.Label labelStatistics;
    }
}

