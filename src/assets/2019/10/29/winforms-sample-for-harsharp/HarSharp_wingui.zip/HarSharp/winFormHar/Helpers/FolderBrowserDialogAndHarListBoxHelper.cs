﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winFormHar.Helpers
{
    public static class FolderBrowserDialogAndHarListBoxHelper
    {
        public static void ShowFolderDialogAndAddHARFilesToListBox(this ListBox listBoxHARFiles, Dictionary<string, string> fileNameLookupDictionary)
        {
            using (var folderBrowserDialog = new FolderBrowserDialog())
            {
                SetupFolderBrowserDialogProperties(folderBrowserDialog);
                DialogResult result = folderBrowserDialog.ShowDialog();

                if (IsValidFolder(folderBrowserDialog, result))
                {
                    listBoxHARFiles.AddHarFilesToListBoxAndCache(folderBrowserDialog, fileNameLookupDictionary);
                }
            }
        }

        private static void SetupFolderBrowserDialogProperties(FolderBrowserDialog folderBrowserDialog)
        {
            folderBrowserDialog.Description = $"{Environment.NewLine}Select HAR Folder:";
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = false;
        }

        public static bool IsValidFolder(FolderBrowserDialog folderBrowserDialog, DialogResult result)
        {
            return result == DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog.SelectedPath);
        }

        public static bool NoItemsInListbox(this ListBox listBoxHARFiles)
        {
            if (listBoxHARFiles.SelectedItem == null) { return true; }
            return listBoxHARFiles.SelectedItem.ToString().StartsWith("**");
        }

        public static void AddHarFilesToListBoxAndCache(this ListBox listBoxHARFiles, FolderBrowserDialog folderBrowserDialog, Dictionary<string, string> fileNameLookupDictionary)
        {
            fileNameLookupDictionary.Clear();
            foreach (var fullFileName in Directory.GetFiles(folderBrowserDialog.SelectedPath).ToList())
            {
                var fileName = Path.GetFileName(fullFileName);
                if (Path.GetExtension(fullFileName).ToLower().Equals(".har", StringComparison.OrdinalIgnoreCase))
                {
                    fileNameLookupDictionary.Add(fileName, fullFileName);
                    listBoxHARFiles.Items.Add(fileName);
                }
            }
        }


    }
}
