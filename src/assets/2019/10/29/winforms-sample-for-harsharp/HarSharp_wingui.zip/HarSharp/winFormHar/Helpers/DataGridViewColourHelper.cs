﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winFormHar.Helpers
{
    public static class DataGridViewColourHelper
    {
        public static void ColourHarDataGridView(this DataGridView dataGridViewHAR)
        {
            for (int k = 0; k < dataGridViewHAR.Rows.Count; k++)
            {
                dataGridViewHAR.ColourOKStatusCellsYellow(k);
                dataGridViewHAR.ColourOtherStatusCellsSalmon(k);
            }
        }

        public static void ColourCell(this DataGridView dataGridView, int i, string id, Color colour)
        {
            try
            {
                dataGridView.Rows[i].Cells[id].Style.BackColor = colour;
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch
            {
                // if this fails for any reason do not crash, just do not do the colouring
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        public static void ColourOtherStatusCellsSalmon(this DataGridView dataGridViewHAR, int rowIndex)
        {
            if (!string.Equals(dataGridViewHAR.Rows[rowIndex].Cells[DataTableHelper.Har_StatusText].Value.ToString(), "ok", StringComparison.OrdinalIgnoreCase))
            {
                dataGridViewHAR.ColourCell(rowIndex, DataTableHelper.Har_Id, Color.LightSalmon);
                dataGridViewHAR.ColourCell(rowIndex, DataTableHelper.Har_Status, Color.LightSalmon);
                dataGridViewHAR.ColourCell(rowIndex, DataTableHelper.Har_StatusText, Color.LightSalmon);
            }
        }

        public static void ColourOKStatusCellsYellow(this DataGridView dataGridViewHAR, int rowIndex)
        {
            if (string.Equals(dataGridViewHAR.Rows[rowIndex].Cells[DataTableHelper.Har_StatusText].Value.ToString(), "ok", StringComparison.OrdinalIgnoreCase))
            {
                dataGridViewHAR.ColourCell(rowIndex, DataTableHelper.Har_Id, Color.LightGoldenrodYellow);
                dataGridViewHAR.ColourCell(rowIndex, DataTableHelper.Har_Status, Color.LightGoldenrodYellow);
                dataGridViewHAR.ColourCell(rowIndex, DataTableHelper.Har_StatusText, Color.LightGoldenrodYellow);
            }
        }
    }
}
