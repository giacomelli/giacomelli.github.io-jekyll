﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winFormHar.Helpers
{
    public static class DataGridViewHelper
    {

        public static void UpdateListBoxIfNoHARFiles(this ListBox listBoxHARFiles)
        {
            if (listBoxHARFiles.Items.Count == 0)
            {
                listBoxHARFiles.Items.Add("** No HAR Files Found **");
            }
        }

        public static void StatisticsDisplayForNoRowsSelected(this Label labelStatistics, int rowIndex)
        {
            if (rowIndex == -1)
            {
                labelStatistics.Text = "Statistics:";
            }
        }

        public static void StatisticsDisplayForASelectedRow(this Label labelStatistics, int rowIndex, DataGridView dataGridViewHAR,
            Dictionary<string, (int rows, int? sizes, double? times)> statisticsDict)
        {
            if (rowIndex > -1)
            {
                DataGridViewRow row = dataGridViewHAR.Rows[rowIndex];
                var rowName = row.Cells[DataTableHelper.Har_Name].Value;

                int totalSize = statisticsDict[rowName.ToString()].sizes ?? 0;
                double? totalTime = statisticsDict[rowName.ToString()].times;

                labelStatistics.Text = $"Total Rows: {statisticsDict[rowName.ToString()].rows}   Total Size: {totalSize.ToConvertedSize()}   Total Time: {totalTime.ToConvertedTime()}";
            }
        }       
    }
}
