﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winFormHar.Helpers
{
    public static class SizeAndTimeHelper
    {
        public static string ToConvertedTime(this double? rawTime)
        {
            if (rawTime == null) { return string.Empty; }

            if (rawTime < 1000) { return DisplayAsMilliSeconds(rawTime); }

            if (rawTime < 60000) { return DisplayAsSeconds(rawTime); }

            return DisplayAsMinutes(rawTime);
        }

        private static string DisplayAsMilliSeconds(double? rawTime)
        {
            return $"{rawTime} ms";
        }

        private static string DisplayAsSeconds(double? rawTime)
        {
            return $"{((double)(rawTime / 1000.0)).ToString("N2")} s";
        }

        private static string DisplayAsMinutes(double? rawTime)
        {
            return $"{((double)(rawTime / 60000.0)).ToString("N1")} min";
        }

        public static string ToConvertedSize(this int rawSize)
        {
            if (rawSize < 1024) { return DisplayAsBytes(rawSize); }

            // 1024 * 100 = 102400
            if (rawSize < 102400) { return DisplayAsSmallKiloBytes(rawSize); }

            // 1024 * 1024 = 1048576
            if (rawSize < 1048576) { return DisplayAsBigKiloBytes(rawSize); }

            return DisplayAsMegaBytes(rawSize);
        }

        private static string DisplayAsBytes(int rawSize)
        {
            return $"{rawSize} B";
        }

        private static string DisplayAsSmallKiloBytes(int rawSize)
        {
            return $"{(rawSize / 1024.0).ToString("N1")} KB";
        }

        private static string DisplayAsBigKiloBytes(int rawSize)
        {
            return $"{(rawSize / 1024.0).ToString("N0")} KB";
        }

        private static string DisplayAsMegaBytes(int rawSize)
        {
            // 1024 * 1024 = 1048576
            return $"{(rawSize / 1048576.0).ToString("N1")} MB";
        }
    }
}
